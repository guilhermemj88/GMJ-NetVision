export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        graphite: {
          900: '#0a0c0f',
          850: '#0f1216',
          800: '#14181d',
          750: '#191e24',
          700: '#232a32',
          600: '#2d3640',
          500: '#3d4854',
        },
        steel: {
          300: '#a9c6dd',
          400: '#7ea6c9',
          500: '#5b87ad',
          600: '#3f6685',
        },
        accent: {
          200: '#ddd6fe',
          300: '#c4b5fd',
          400: '#a78bfa',
          500: '#8b5cf6',
          600: '#7c3aed',
        },
        ink: {
          100: '#e6ebf2',
          300: '#aab6c4',
          500: '#7c8896',
          700: '#586373',
        },
        ok: '#34d399',
        warn: '#f59e0b',
        crit: '#f43f5e',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
    },
  },
}
