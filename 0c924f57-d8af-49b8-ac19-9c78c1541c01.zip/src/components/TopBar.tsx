import React from 'react';
import {
  CableIcon,
  EyeOffIcon,
  LayersIcon,
  MinusIcon,
  PlusIcon,
  ServerIcon } from
'lucide-react';
import type { ConnectionMode, Pop, Rack } from '../types/network';

interface Props {
  pop: Pop;
  rack: Rack;
  deviceCount: number;
  connectionCount: number;
  mode: ConnectionMode;
  onMode: (mode: ConnectionMode) => void;
  zoom: number;
  onZoom: (zoom: number) => void;
}

const MODES: {id: ConnectionMode;label: string;icon: React.ReactNode;}[] = [
{ id: 'hidden', label: 'Hidden', icon: <EyeOffIcon className="h-3.5 w-3.5" /> },
{
  id: 'selected',
  label: 'Selected only',
  icon: <CableIcon className="h-3.5 w-3.5" />
},
{ id: 'all', label: 'All', icon: <LayersIcon className="h-3.5 w-3.5" /> }];


export function TopBar({
  pop,
  rack,
  deviceCount,
  connectionCount,
  mode,
  onMode,
  zoom,
  onZoom
}: Props) {
  return (
    <header className="flex shrink-0 items-center gap-6 border-b border-graphite-700 bg-graphite-850 px-5 py-2.5">
      <div className="min-w-0">
        <div className="flex items-center gap-2 font-mono text-[11px] text-ink-500">
          <span className="text-ink-300">{pop.name}</span>
          <span className="text-ink-700">/</span>
          <span className="text-ink-100">{rack.name}</span>
          <span className="text-ink-700">·</span>
          <span>{rack.room}</span>
        </div>
        <h1 className="text-[13px] font-medium tracking-tight text-ink-100">
          Physical POP / Rack View
        </h1>
      </div>

      <div className="flex items-center gap-4 border-l border-graphite-700 pl-5 font-mono text-[11px] text-ink-300">
        <span className="flex items-center gap-1.5">
          <ServerIcon className="h-3.5 w-3.5 text-steel-400" />
          {deviceCount} devices
        </span>
        <span className="flex items-center gap-1.5">
          <CableIcon className="h-3.5 w-3.5 text-steel-400" />
          {connectionCount} links
        </span>
        <span className="flex items-center gap-1.5">
          {rack.units}U frame
        </span>
      </div>

      <div className="ml-auto flex items-center gap-4">
        <div className="hidden items-center gap-3 font-mono text-[10px] text-ink-500 xl:flex">
          <span className="flex items-center gap-1.5">
            <svg width="20" height="6" aria-hidden="true">
              <line x1="0" y1="3" x2="20" y2="3" stroke="#7ea6c9" strokeWidth="1.6" />
            </svg>
            Fiber
          </span>
          <span className="flex items-center gap-1.5">
            <svg width="20" height="6" aria-hidden="true">
              <line
                x1="0"
                y1="3"
                x2="20"
                y2="3"
                stroke="#7ea6c9"
                strokeWidth="1.6"
                strokeDasharray="4 4" />
              
            </svg>
            Ethernet
          </span>
          <span className="flex items-center gap-1.5">
            <i className="h-1.5 w-1.5 rounded-full bg-ok" /> Up
          </span>
          <span className="flex items-center gap-1.5">
            <i className="h-1.5 w-1.5 rounded-full bg-warn" /> Degraded
          </span>
          <span className="flex items-center gap-1.5">
            <i className="h-1.5 w-1.5 rounded-full bg-crit" /> Down
          </span>
        </div>

        <div
          className="flex items-center rounded-[4px] border border-graphite-600 bg-graphite-800 p-0.5"
          role="group"
          aria-label="Connection display mode">
          
          {MODES.map((m) =>
          <button
            key={m.id}
            type="button"
            aria-pressed={mode === m.id}
            onClick={() => onMode(m.id)}
            className={`flex items-center gap-1.5 rounded-[3px] px-2.5 py-1 font-mono text-[10.5px] transition-colors duration-150 ease-out ${
            mode === m.id ?
            'bg-accent-600/25 text-accent-300 ring-1 ring-accent-500/50' :
            'text-ink-500 hover:text-ink-300'}`
            }>
            
              {m.icon}
              {m.label}
            </button>
          )}
        </div>

        <div className="flex items-center rounded-[4px] border border-graphite-600 bg-graphite-800">
          <button
            type="button"
            aria-label="Zoom out"
            onClick={() => onZoom(Math.max(0.7, Math.round((zoom - 0.15) * 100) / 100))}
            className="px-2 py-1 text-ink-500 transition-colors duration-150 ease-out hover:text-ink-100">
            
            <MinusIcon className="h-3.5 w-3.5" />
          </button>
          <span className="w-10 text-center font-mono text-[10.5px] text-ink-300">
            {Math.round(zoom * 100)}%
          </span>
          <button
            type="button"
            aria-label="Zoom in"
            onClick={() => onZoom(Math.min(1.6, Math.round((zoom + 0.15) * 100) / 100))}
            className="px-2 py-1 text-ink-500 transition-colors duration-150 ease-out hover:text-ink-100">
            
            <PlusIcon className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </header>);

}