import React from 'react';
import {
  ArrowDownIcon,
  CircleDotIcon,
  ExternalLinkIcon,
  MousePointerClickIcon,
  XIcon } from
'lucide-react';
import type {
  Connection,
  Device,
  DeviceTemplate,
  Endpoint,
  RearLink,
  Selection } from
'../types/network';
import { KIND_LABEL } from '../data/templates';
import { KIND_STRIPE, KIND_TEXT, STATUS_DOT, STATUS_LABEL } from '../utils/style';
import {
  findConnectionForPort,
  otherEnd,
  portKey,
  tracePath,
  type PathItem } from
'../utils/path';

interface Props {
  selection: Selection;
  devices: Device[];
  templates: Record<string, DeviceTemplate>;
  connections: Connection[];
  rearLinks: Record<string, RearLink>;
  onSelectPort: (deviceId: string, portId: string) => void;
  onSelectDevice: (deviceId: string) => void;
  onClear: () => void;
}

const Row = ({ label, value }: {label: string;value: React.ReactNode;}) =>
<div className="flex items-baseline justify-between gap-3 border-b border-graphite-700/60 py-1.5">
    <span className="font-mono text-[10px] uppercase tracking-wider text-ink-700">
      {label}
    </span>
    <span className="truncate text-right font-mono text-[11.5px] text-ink-100">
      {value}
    </span>
  </div>;


const Header = ({
  eyebrow,
  title,
  sub,
  onClear





}: {eyebrow: string;title: string;sub?: string;onClear: () => void;}) =>
<div className="flex items-start gap-2 border-b border-graphite-700 px-4 py-3">
    <div className="min-w-0 flex-1">
      <span className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-accent-400">
        {eyebrow}
      </span>
      <h2 className="truncate font-mono text-[13px] text-ink-100">{title}</h2>
      {sub && <p className="truncate font-mono text-[10.5px] text-ink-500">{sub}</p>}
    </div>
    <button
    type="button"
    onClick={onClear}
    aria-label="Clear selection"
    className="rounded-[3px] border border-graphite-600 p-1 text-ink-500 transition-colors duration-150 ease-out hover:text-ink-100">
    
      <XIcon className="h-3.5 w-3.5" />
    </button>
  </div>;


function PathChain({ items }: {items: PathItem[];}) {
  return (
    <ol className="space-y-0">
      {items.map((item, i) =>
      item.kind === 'node' ?
      <li
        key={i}
        className={`flex items-center gap-2 rounded-[3px] border px-2 py-1.5 ${
        item.deviceKind === 'external' ?
        'border-graphite-600 border-dashed bg-graphite-850' :
        'border-graphite-600 bg-graphite-800'}`
        }>
        
            {item.deviceKind === 'external' ?
        <ExternalLinkIcon className="h-3.5 w-3.5 shrink-0 text-steel-400" /> :

        <i
          className={`h-5 w-[3px] shrink-0 rounded-full ${KIND_STRIPE[item.deviceKind]}`} />

        }
            <span className="min-w-0 flex-1">
              <span className="block truncate font-mono text-[11px] text-ink-100">
                {item.deviceName}
              </span>
              <span className="block truncate font-mono text-[9.5px] text-ink-500">
                {item.deviceKind === 'external' ?
            item.note ?? 'Fora do rack' :
            KIND_LABEL[item.deviceKind]}
                {item.passthrough ? ' · pass-through' : ''}
              </span>
            </span>
            <span className="shrink-0 rounded-[2px] border border-steel-600/60 bg-steel-600/15 px-1.5 py-0.5 font-mono text-[10px] text-steel-300">
              {item.portName}
            </span>
          </li> :

      <li key={i} className="flex items-center gap-2 py-1 pl-3">
            <ArrowDownIcon className="h-3 w-3 text-accent-400" />
            <span className="font-mono text-[9.5px] uppercase tracking-wider text-ink-500">
              {item.label}
              <span className="ml-1.5 text-ink-700">
                {item.type === 'fiber' ? 'fiber' : 'ethernet'}
              </span>
            </span>
          </li>

      )}
    </ol>);

}

export function DetailDrawer({
  selection,
  devices,
  templates,
  connections,
  rearLinks,
  onSelectPort,
  onSelectDevice,
  onClear
}: Props) {
  const ctx = { devices, templates, connections, rearLinks };
  const deviceById = new Map(devices.map((d) => [d.id, d]));
  const nameOf = (id: string) => deviceById.get(id)?.name ?? id;

  const renderConnection = (conn: Connection, local: Endpoint) => {
    const remote = otherEnd(conn, local);
    const path = tracePath(local, ctx);
    const passesThrough = path.filter(
      (i) => i.kind === 'node' && i.passthrough
    ).length;
    return (
      <>
        <section className="px-4 py-3">
          <h3 className="pb-1 font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-700">
            Connection
          </h3>
          <Row label="Local device" value={nameOf(local.deviceId)} />
          <Row label="Local port" value={local.portId} />
          <Row label="Remote device" value={nameOf(remote.deviceId)} />
          <Row label="Remote port" value={remote.portId} />
          <Row
            label="Type"
            value={conn.type === 'fiber' ? 'Fiber' : 'Ethernet'} />
          
          <Row
            label="Status"
            value={
            <span className="inline-flex items-center gap-1.5">
                <i className={`h-1.5 w-1.5 rounded-full ${STATUS_DOT[conn.status]}`} />
                {STATUS_LABEL[conn.status]}
              </span>
            } />
          
          {conn.circuit && <Row label="Circuit" value={conn.circuit} />}
          <Row label="Link ID" value={conn.id.toUpperCase()} />
        </section>
        <section className="px-4 pb-4">
          <h3 className="flex items-center justify-between pb-1.5 font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-700">
            Physical path
            {passesThrough > 0 &&
            <span className="rounded-[2px] border border-ok/40 bg-ok/10 px-1.5 py-0.5 text-[9px] normal-case tracking-normal text-ok">
                passa por DIO / patch panel
              </span>
            }
          </h3>
          <PathChain items={path} />
        </section>
      </>);

  };

  if (selection.kind === 'connection') {
    const conn = connections.find((c) => c.id === selection.connectionId);
    if (conn) {
      return (
        <Panel>
          <Header
            eyebrow="Selected connection"
            title={`${nameOf(conn.a.deviceId)} ↔ ${nameOf(conn.b.deviceId)}`}
            sub={conn.circuit}
            onClear={onClear} />
          
          {renderConnection(conn, conn.a)}
        </Panel>);

    }
  }

  if (selection.kind === 'port') {
    const device = deviceById.get(selection.deviceId);
    const tpl = device ? templates[device.templateId] : undefined;
    if (device && tpl) {
      const port = tpl.groups.
      flatMap((g) => g.ports).
      find((p) => p.id === selection.portId);
      const conn = findConnectionForPort(
        connections,
        selection.deviceId,
        selection.portId
      );
      const rear = rearLinks[portKey(selection.deviceId, selection.portId)];
      return (
        <Panel>
          <Header
            eyebrow="Selected port"
            title={`${device.name} · ${selection.portId}`}
            sub={`${tpl.vendor} ${tpl.model} · U${device.startU} · ${
            port?.media === 'fiber' ? 'Optical' : 'Copper'}`
            }
            onClear={onClear} />
          
          <div className="border-b border-graphite-700 px-4 py-2">
            <button
              type="button"
              onClick={() => onSelectDevice(device.id)}
              className="font-mono text-[10.5px] text-steel-400 underline-offset-2 hover:underline">
              
              ← Ver equipamento completo
            </button>
          </div>
          {conn ?
          renderConnection(conn, {
            deviceId: selection.deviceId,
            portId: selection.portId
          }) :

          <section className="px-4 py-4">
              <div className="rounded-[3px] border border-dashed border-graphite-600 bg-graphite-850 px-3 py-4 text-center">
                <CircleDotIcon className="mx-auto h-4 w-4 text-ink-700" />
                <p className="mt-1.5 font-mono text-[11px] text-ink-300">
                  Porta livre
                </p>
                <p className="mt-0.5 font-mono text-[10px] text-ink-700">
                  Nenhum enlace físico terminado nesta porta.
                </p>
              </div>
              {rear &&
            <p className="mt-3 font-mono text-[10px] text-ink-500">
                  Lado traseiro: {rear.label} → {rear.chain[0]?.device}
                </p>
            }
            </section>
          }
        </Panel>);

    }
  }

  if (selection.kind === 'device') {
    const device = deviceById.get(selection.deviceId);
    const tpl = device ? templates[device.templateId] : undefined;
    if (device && tpl) {
      const ports = tpl.groups.flatMap((g) => g.ports);
      const links = ports.
      map((p) => ({
        port: p,
        conn: findConnectionForPort(connections, device.id, p.id)
      })).
      filter((x) => !!x.conn);
      return (
        <Panel>
          <Header
            eyebrow="Selected device"
            title={device.name}
            sub={`${tpl.vendor} ${tpl.model}`}
            onClear={onClear} />
          
          <section className="px-4 py-3">
            <Row
              label="Type"
              value={
              <span className={KIND_TEXT[tpl.kind]}>{KIND_LABEL[tpl.kind]}</span>
              } />
            
            <Row
              label="Position"
              value={
              tpl.heightU > 1 ?
              `U${device.startU}–U${device.startU + tpl.heightU - 1}` :
              `U${device.startU}`
              } />
            
            <Row label="Height" value={`${tpl.heightU}U`} />
            <Row label="Ports" value={`${links.length} / ${ports.length} in use`} />
            {tpl.passthrough && <Row label="Role" value="Pass-through físico" />}
            {device.note && <Row label="Note" value={device.note} />}
          </section>
          <section className="min-h-0 flex-1 overflow-y-auto rack-scroll px-4 pb-4">
            <h3 className="pb-1.5 font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-700">
              Ports in use
            </h3>
            <ul className="space-y-0.5">
              {links.map(({ port, conn }) => {
                const c = conn as Connection;
                const remote = otherEnd(c, {
                  deviceId: device.id,
                  portId: port.id
                });
                return (
                  <li key={port.id}>
                    <button
                      type="button"
                      onClick={() => onSelectPort(device.id, port.id)}
                      className="flex w-full items-center gap-2 rounded-[3px] border border-graphite-700 bg-graphite-800/70 px-2 py-1.5 text-left transition-colors duration-150 ease-out hover:border-accent-500/50">
                      
                      <span className="shrink-0 rounded-[2px] border border-steel-600/60 bg-steel-600/15 px-1.5 py-0.5 font-mono text-[10px] text-steel-300">
                        {port.name}
                      </span>
                      <span className="min-w-0 flex-1 truncate font-mono text-[10.5px] text-ink-300">
                        {nameOf(remote.deviceId)} · {remote.portId}
                      </span>
                      <i
                        className={`h-1.5 w-1.5 shrink-0 rounded-full ${STATUS_DOT[c.status]}`} />
                      
                    </button>
                  </li>);

              })}
              {links.length === 0 &&
              <li className="font-mono text-[10.5px] text-ink-700">
                  Nenhuma porta conectada.
                </li>
              }
            </ul>
          </section>
        </Panel>);

    }
  }

  return (
    <Panel>
      <div className="border-b border-graphite-700 px-4 py-3">
        <span className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-700">
          Inspector
        </span>
        <h2 className="font-mono text-[13px] text-ink-300">Nada selecionado</h2>
      </div>
      <div className="px-4 py-6 text-center">
        <MousePointerClickIcon className="mx-auto h-5 w-5 text-ink-700" />
        <p className="mt-2 font-mono text-[11px] text-ink-300">
          Selecione um equipamento ou porta
        </p>
        <p className="mx-auto mt-1.5 max-w-[230px] font-mono text-[10px] leading-relaxed text-ink-700">
          Clique em um equipamento para revelar seus enlaces, ou em uma porta para
          destacar o caminho físico ponta a ponta — incluindo DIOs e patch panels
          no meio do percurso.
        </p>
      </div>
    </Panel>);

}

function Panel({ children }: {children: React.ReactNode;}) {
  return (
    <aside
      aria-label="Selection details"
      className="flex w-[358px] shrink-0 flex-col overflow-y-auto rack-scroll border-l border-graphite-700 bg-graphite-850">
      
      {children}
    </aside>);

}