import React, { useEffect, useMemo, useRef, useState } from 'react';
import type {
  Connection,
  ConnectionFilters,
  ConnectionMode,
  Device,
  DeviceTemplate,
  LinkStatus,
  LinkType,
  PortFilter,
  Rack,
  RearLink,
  Selection } from
'../types/network';
import {
  CANVAS_H,
  CANVAS_W,
  DEVICE_W,
  DEVICE_X,
  LANE_X,
  RACK_U,
  RAIL_W,
  TRACK_COUNT,
  U_H,
  assignTracks,
  cablePath,
  deviceTopY,
  exitPath,
  portPoint,
  trackX } from
'../utils/geometry';
import { findConnectionForPort, portKey } from '../utils/path';
import { DeviceUnit, type PortTooltip } from './DeviceUnit';
import { CableLayer, type RenderedCable } from './CableLayer';
import { STATUS_DOT } from '../utils/style';

interface Props {
  rack: Rack;
  racks: Rack[];
  devices: Device[];
  templates: Record<string, DeviceTemplate>;
  connections: Connection[];
  rearLinks: Record<string, RearLink>;
  filters: ConnectionFilters;
  mode: ConnectionMode;
  selection: Selection;
  portFilter: PortFilter;
  zoom: number;
  onSelectDevice: (deviceId: string) => void;
  onSelectPort: (deviceId: string, portId: string) => void;
  onSelectConnection: (connectionId: string) => void;
  onClear: () => void;
}

export function RackCanvas({
  rack,
  racks,
  devices,
  templates,
  connections,
  rearLinks,
  filters,
  mode,
  selection,
  portFilter,
  zoom,
  onSelectDevice,
  onSelectPort,
  onSelectConnection,
  onClear
}: Props) {
  const [tip, setTip] = useState<PortTooltip | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const deviceById = useMemo(
    () => new Map(devices.map((d) => [d.id, d])),
    [devices]
  );
  const rackById = useMemo(() => new Map(racks.map((r) => [r.id, r])), [racks]);
  const rackDevices = useMemo(
    () => devices.filter((d) => d.rackId === rack.id),
    [devices, rack.id]
  );

  const tplOf = (d: Device) => templates[d.templateId];

  /** portKey → link info, for port colouring and tooltips. */
  const portLinkIndex = useMemo(() => {
    const map = new Map<
      string,
      {status: LinkStatus;type: LinkType;remote: string;}>(
    );
    for (const c of connections) {
      const an = deviceById.get(c.a.deviceId)?.name ?? c.a.deviceId;
      const bn = deviceById.get(c.b.deviceId)?.name ?? c.b.deviceId;
      map.set(portKey(c.a.deviceId, c.a.portId), {
        status: c.status,
        type: c.type,
        remote: `${bn} · ${c.b.portId}`
      });
      map.set(portKey(c.b.deviceId, c.b.portId), {
        status: c.status,
        type: c.type,
        remote: `${an} · ${c.a.portId}`
      });
    }
    return map;
  }, [connections, deviceById]);

  const highlightConn = useMemo(() => {
    if (selection.kind === 'connection')
    return connections.find((c) => c.id === selection.connectionId) ?? null;
    if (selection.kind === 'port')
    return (
      findConnectionForPort(
        connections,
        selection.deviceId,
        selection.portId
      ) ?? null);

    return null;
  }, [selection, connections]);

  const focusDeviceIds = useMemo(() => {
    const set = new Set<string>();
    if (selection.kind === 'device') set.add(selection.deviceId);
    if (selection.kind === 'port') set.add(selection.deviceId);
    if (highlightConn) {
      set.add(highlightConn.a.deviceId);
      set.add(highlightConn.b.deviceId);
    }
    return set;
  }, [selection, highlightConn]);

  const isRelated = (c: Connection) => {
    if (highlightConn) return c.id === highlightConn.id;
    if (selection.kind === 'device')
    return (
      c.a.deviceId === selection.deviceId || c.b.deviceId === selection.deviceId);

    return false;
  };

  const relatedDeviceIds = useMemo(() => {
    const set = new Set<string>();
    for (const c of connections) {
      if (!isRelated(c)) continue;
      set.add(c.a.deviceId);
      set.add(c.b.deviceId);
    }
    return set;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connections, selection, highlightConn]);

  const cables = useMemo<RenderedCable[]>(() => {
    if (mode === 'hidden') return [];

    const passes = (c: Connection) => {
      if (c.type === 'fiber' && !filters.fiber) return false;
      if (c.type === 'ethernet' && !filters.ethernet) return false;
      const ra = deviceById.get(c.a.deviceId)?.rackId;
      const rb = deviceById.get(c.b.deviceId)?.rackId;
      const cross = ra !== rb;
      if (cross && !filters.crossRack) return false;
      if (!cross && !filters.sameRack) return false;
      return true;
    };

    const touchesRack = (c: Connection) =>
    deviceById.get(c.a.deviceId)?.rackId === rack.id ||
    deviceById.get(c.b.deviceId)?.rackId === rack.id;

    let pool = connections.filter((c) => passes(c) && touchesRack(c));
    if (mode === 'selected') pool = pool.filter(isRelated);

    interface Draft {
      id: string;
      connectionId?: string;
      type: LinkType;
      status: LinkStatus;
      tone: RenderedCable['tone'];
      x0: number;
      y0: number;
      x1: number;
      y1: number;
      ends: {x: number;y: number;}[];
      label?: string;
      exit?: boolean;
    }

    const drafts: Draft[] = [];
    let exitSlot = 0;

    for (const c of pool) {
      const da = deviceById.get(c.a.deviceId);
      const db = deviceById.get(c.b.deviceId);
      if (!da || !db) continue;
      const ta = templates[da.templateId];
      const tb = templates[db.templateId];
      if (!ta || !tb) continue;
      const tone: RenderedCable['tone'] =
      highlightConn && c.id === highlightConn.id ?
      'high' :
      isRelated(c) ?
      'related' :
      'dim';

      const aIn = da.rackId === rack.id;
      const bIn = db.rackId === rack.id;

      if (aIn && bIn) {
        const pa = portPoint(da, ta, c.a.portId);
        const pb = portPoint(db, tb, c.b.portId);
        if (!pa || !pb) continue;
        drafts.push({
          id: c.id,
          connectionId: c.id,
          type: c.type,
          status: c.status,
          tone,
          x0: pa.right,
          y0: pa.cy,
          x1: pb.right,
          y1: pb.cy,
          ends: [
          { x: pa.right, y: pa.cy },
          { x: pb.right, y: pb.cy }]

        });
      } else {
        const near = aIn ? { d: da, t: ta, p: c.a.portId } : { d: db, t: tb, p: c.b.portId };
        const far = aIn ? db : da;
        const pn = portPoint(near.d, near.t, near.p);
        if (!pn) continue;
        const exitY = 14 + exitSlot * 17;
        exitSlot += 1;
        drafts.push({
          id: c.id,
          connectionId: c.id,
          type: c.type,
          status: c.status,
          tone,
          x0: pn.right,
          y0: pn.cy,
          x1: CANVAS_W - 6,
          y1: exitY,
          ends: [{ x: pn.right, y: pn.cy }],
          label: `→ ${rackById.get(far.rackId)?.name ?? far.rackId} · ${far.name}`,
          exit: true
        });
      }
    }

    // Rear-side continuation of the highlighted path (DIO / patch panel).
    if (highlightConn) {
      for (const ep of [highlightConn.a, highlightConn.b]) {
        const dev = deviceById.get(ep.deviceId);
        if (!dev || dev.rackId !== rack.id) continue;
        const tpl = templates[dev.templateId];
        if (!tpl?.passthrough) continue;
        const rear = rearLinks[portKey(ep.deviceId, ep.portId)];
        const pt = portPoint(dev, tpl, ep.portId);
        if (!rear || !pt) continue;
        const hop = rear.chain[0];
        drafts.push({
          id: `${highlightConn.id}-${ep.deviceId}-rear`,
          type: rear.type,
          status: highlightConn.status,
          tone: 'high',
          x0: pt.right,
          y0: pt.cy,
          x1: CANVAS_W - 6,
          y1: pt.cy,
          ends: [{ x: pt.right, y: pt.cy }],
          label: `→ ${hop.device} · ${hop.port}`,
          exit: true
        });
      }
    }

    const tracks = assignTracks(
      drafts.map((d) => ({ id: d.id, y0: d.y0, y1: d.y1 }))
    );

    return drafts.map((d) => {
      const laneX = trackX(tracks[d.id] ?? 0);
      const straightRear = d.id.endsWith('-rear');
      const path = straightRear ?
      `M ${d.x0} ${d.y0} L ${d.x1} ${d.y1}` :
      d.exit ?
      exitPath(d.x0, d.y0, laneX, d.y1, d.x1) :
      cablePath(d.x0, d.y0, d.x1, d.y1, laneX);
      return {
        id: d.id,
        connectionId: d.connectionId,
        d: path,
        tone: d.tone,
        type: d.type,
        status: d.status,
        ends: d.ends,
        label: d.tone === 'high' ? d.label : undefined,
        labelX: d.tone === 'high' && d.label ? CANVAS_W - 6 - (d.label.length * 5.4 + 10) : undefined,
        labelY: d.tone === 'high' && d.label ? d.y1 - 12 : undefined
      };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
  connections,
  deviceById,
  filters,
  highlightConn,
  mode,
  rack.id,
  rackById,
  rearLinks,
  selection,
  templates]
  );

  // Keep the focused device in view.
  const focusKey = [...focusDeviceIds].sort().join(',');
  useEffect(() => {
    const el = scrollRef.current;
    if (!el || focusDeviceIds.size === 0) return;
    const first = rackDevices.find((d) => focusDeviceIds.has(d.id));
    if (!first) return;
    const tpl = templates[first.templateId];
    if (!tpl) return;
    const y = deviceTopY(first.startU, tpl.heightU) * zoom;
    el.scrollTo({ top: Math.max(0, y - el.clientHeight / 2), behavior: 'smooth' });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusKey]);

  const highlightedPortsByDevice = useMemo(() => {
    const map = new Map<string, Set<string>>();
    if (highlightConn) {
      for (const ep of [highlightConn.a, highlightConn.b]) {
        const set = map.get(ep.deviceId) ?? new Set<string>();
        set.add(ep.portId);
        map.set(ep.deviceId, set);
      }
    }
    return map;
  }, [highlightConn]);

  return (
    <div className="relative min-w-0 flex-1 overflow-hidden bg-graphite-900">
      <div
        ref={scrollRef}
        className="h-full overflow-auto rack-scroll"
        onClick={onClear}>
        
        <div
          style={{ width: CANVAS_W * zoom + 64, height: CANVAS_H * zoom + 96 }}
          className="relative px-8 py-10">
          
          <div
            style={{
              width: CANVAS_W,
              height: CANVAS_H,
              transform: `scale(${zoom})`,
              transformOrigin: 'top left'
            }}
            className="relative"
            onClick={(e) => e.stopPropagation()}>
            
            {/* Rack frame */}
            <div
              className="absolute top-0 rounded-[4px] border border-graphite-600 bg-graphite-850"
              style={{ left: 0, width: DEVICE_X + DEVICE_W + 8, height: CANVAS_H }} />
            
            {/* U rows */}
            {Array.from({ length: RACK_U }, (_, i) => {
              const u = RACK_U - i;
              const major = u % 5 === 0;
              return (
                <div
                  key={u}
                  className="absolute flex items-center"
                  style={{ left: 0, top: i * U_H, height: U_H, width: DEVICE_X + DEVICE_W + 8 }}>
                  
                  <div
                    className={`h-full w-full border-t ${
                    major ? 'border-graphite-600/80' : 'border-graphite-700/60'} ${
                    u % 2 === 0 ? 'bg-graphite-800/25' : ''}`} />
                  
                  <span
                    className={`absolute left-0 pl-2 font-mono text-[9.5px] ${
                    major ? 'text-ink-300' : 'text-ink-700'}`
                    }
                    style={{ width: RAIL_W }}>
                    
                    {String(u).padStart(2, '0')}
                  </span>
                  <span
                    className="absolute font-mono text-[9px] text-graphite-500"
                    style={{ left: DEVICE_X + DEVICE_W - 22 }}>
                    
                    {major ? String(u).padStart(2, '0') : ''}
                  </span>
                </div>);

            })}
            {/* Mounting rails */}
            <div
              className="absolute top-0 border-x border-graphite-600/70 bg-graphite-800/40"
              style={{ left: RAIL_W, width: 10, height: CANVAS_H }} />
            
            <div
              className="absolute top-0 border-x border-graphite-600/70 bg-graphite-800/40"
              style={{ left: DEVICE_X + DEVICE_W - 2, width: 10, height: CANVAS_H }} />
            

            {/* Cable lane */}
            <div
              className="absolute top-0"
              style={{ left: LANE_X, width: CANVAS_W - LANE_X, height: CANVAS_H }}>
              
              <div className="absolute inset-y-0 left-0 w-px bg-graphite-700" />
              {mode !== 'hidden' &&
              Array.from({ length: TRACK_COUNT }, (_, i) =>
              <div
                key={i}
                className="absolute inset-y-0 w-px bg-graphite-700/45"
                style={{ left: trackX(i) - LANE_X }} />

              )}
              <span
                className="absolute left-2 top-2 font-mono text-[8.5px] uppercase tracking-[0.2em] text-ink-700"
                aria-hidden="true">
                
                cable lane
              </span>
            </div>

            <CableLayer cables={cables} onSelectConnection={onSelectConnection} />

            {rackDevices.map((device) => {
              const tpl = tplOf(device);
              if (!tpl) return null;
              const state = focusDeviceIds.has(device.id) ?
              'selected' :
              relatedDeviceIds.has(device.id) ?
              'related' :
              'normal';
              const links = new Map<
                string,
                {status: LinkStatus;type: LinkType;remote: string;}>(
              );
              for (const g of tpl.groups) {
                for (const p of g.ports) {
                  const link = portLinkIndex.get(portKey(device.id, p.id));
                  if (link) links.set(p.id, link);
                }
              }
              return (
                <DeviceUnit
                  key={device.id}
                  device={device}
                  tpl={tpl}
                  state={state}
                  selectedPortId={
                  selection.kind === 'port' && selection.deviceId === device.id ?
                  selection.portId :
                  undefined
                  }
                  highlightedPorts={
                  highlightedPortsByDevice.get(device.id) ?? new Set()
                  }
                  portLinks={links}
                  portFilter={portFilter}
                  onSelectDevice={onSelectDevice}
                  onSelectPort={onSelectPort}
                  onHoverPort={setTip} />);


            })}

            {tip &&
            <div
              className="pointer-events-none absolute z-30 -translate-x-1/2 -translate-y-full rounded-[3px] border border-graphite-500 bg-graphite-850 px-2 py-1 shadow-lg"
              style={{ left: tip.x, top: tip.y }}>
              
                <div className="whitespace-nowrap font-mono text-[10px] text-ink-100">
                  {tip.label}
                </div>
                <div className="flex items-center gap-1.5 whitespace-nowrap font-mono text-[9px] text-ink-500">
                  {tip.status &&
                <i className={`h-1.5 w-1.5 rounded-full ${STATUS_DOT[tip.status]}`} />
                }
                  {tip.sub}
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>);

}