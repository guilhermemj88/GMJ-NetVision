import React from 'react';
import type { LinkStatus, LinkType } from '../types/network';
import { CANVAS_H, CANVAS_W } from '../utils/geometry';

export interface RenderedCable {
  id: string;
  connectionId?: string;
  d: string;
  tone: 'high' | 'related' | 'dim';
  type: LinkType;
  status: LinkStatus;
  ends: {x: number;y: number;}[];
  label?: string;
  labelX?: number;
  labelY?: number;
}

interface Props {
  cables: RenderedCable[];
  onSelectConnection: (connectionId: string) => void;
}

const strokeFor = (tone: RenderedCable['tone'], status: LinkStatus) => {
  if (tone === 'dim') return '#3f6685';
  if (status === 'down') return '#f43f5e';
  if (status === 'degraded') return '#f59e0b';
  return tone === 'high' ? '#a78bfa' : '#7ea6c9';
};

const widthFor = (tone: RenderedCable['tone']) =>
tone === 'high' ? 2.1 : tone === 'related' ? 1.4 : 1;

const opacityFor = (tone: RenderedCable['tone']) =>
tone === 'high' ? 1 : tone === 'related' ? 0.7 : 0.1;

export function CableLayer({ cables, onSelectConnection }: Props) {
  return (
    <svg
      className="pointer-events-none absolute inset-0"
      width={CANVAS_W}
      height={CANVAS_H}
      aria-hidden="true">
      
      {cables.map((cable) => {
        const stroke = strokeFor(cable.tone, cable.status);
        return (
          <g key={cable.id}>
            {cable.connectionId &&
            <path
              d={cable.d}
              fill="none"
              stroke="transparent"
              strokeWidth={11}
              className="cursor-pointer"
              style={{ pointerEvents: 'stroke' }}
              onClick={() => onSelectConnection(cable.connectionId as string)} />

            }
            <path
              d={cable.d}
              fill="none"
              stroke={stroke}
              strokeWidth={widthFor(cable.tone)}
              strokeOpacity={opacityFor(cable.tone)}
              strokeLinecap="round"
              strokeDasharray={cable.type === 'ethernet' ? '4 4' : undefined} />
            
            {cable.tone === 'high' &&
            <path
              d={cable.d}
              fill="none"
              stroke="#ede9fe"
              strokeWidth={1.1}
              strokeLinecap="round"
              strokeDasharray="3 13"
              className="cable-flow" />

            }
            {cable.tone !== 'dim' &&
            cable.ends.map((e, i) =>
            <rect
              key={i}
              x={e.x - 2.5}
              y={e.y - 2.5}
              width={5}
              height={5}
              rx={1}
              fill={cable.tone === 'high' ? '#ede9fe' : stroke} />

            )}
            {cable.label && cable.labelX != null && cable.labelY != null &&
            <g>
                <rect
                x={cable.labelX}
                y={cable.labelY - 8}
                width={cable.label.length * 5.4 + 10}
                height={16}
                rx={3}
                fill="#14181d"
                stroke={stroke}
                strokeOpacity={0.6} />
              
                <text
                x={cable.labelX + 5}
                y={cable.labelY + 3.5}
                fill="#e6ebf2"
                className="font-mono"
                fontSize={9}>
                
                  {cable.label}
                </text>
              </g>
            }
          </g>);

      })}
    </svg>);

}