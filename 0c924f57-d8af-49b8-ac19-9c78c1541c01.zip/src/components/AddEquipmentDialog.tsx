import React, { useMemo, useState } from 'react';
import { XIcon } from 'lucide-react';
import type {
  Device,
  DeviceTemplate,
  PortNumberingStyle,
  Rack } from
'../types/network';
import { portName } from '../data/templates';
import { RACK_U } from '../utils/geometry';

export interface GenericDraft {
  name: string;
  heightU: number;
  portCount: number;
  style: PortNumberingStyle;
  media: 'copper' | 'fiber';
  startU: number;
}

interface Props {
  open: boolean;
  rack: Rack;
  devices: Device[];
  templates: Record<string, DeviceTemplate>;
  onClose: () => void;
  onCreate: (draft: GenericDraft) => void;
}

const STYLES: {id: PortNumberingStyle;label: string;}[] = [
{ id: 'port', label: 'P1, P2, P3…' },
{ id: 'numeric', label: '1, 2, 3…' },
{ id: 'padded', label: '01, 02, 03…' },
{ id: 'lan', label: 'LAN1, LAN2…' }];


export function AddEquipmentDialog({
  open,
  rack,
  devices,
  templates,
  onClose,
  onCreate
}: Props) {
  const [draft, setDraft] = useState<GenericDraft>({
    name: 'EDD Cliente Novo',
    heightU: 1,
    portCount: 6,
    style: 'port',
    media: 'copper',
    startU: 24
  });

  const occupied = useMemo(() => {
    const set = new Set<number>();
    for (const d of devices) {
      if (d.rackId !== rack.id) continue;
      const tpl = templates[d.templateId];
      if (!tpl) continue;
      for (let u = d.startU; u < d.startU + tpl.heightU; u += 1) set.add(u);
    }
    return set;
  }, [devices, rack.id, templates]);

  const conflict = useMemo(() => {
    if (draft.startU < 1 || draft.startU + draft.heightU - 1 > RACK_U)
    return `Fora do frame de ${RACK_U}U.`;
    for (let u = draft.startU; u < draft.startU + draft.heightU; u += 1) {
      if (occupied.has(u)) return `U${u} já está ocupado.`;
    }
    if (!draft.name.trim()) return 'Informe um nome.';
    if (draft.portCount < 1 || draft.portCount > 48) return '1 a 48 portas.';
    return null;
  }, [draft, occupied]);

  if (!open) return null;

  const preview = Array.from({ length: Math.min(draft.portCount, 8) }, (_, i) =>
  portName(draft.style, i)
  ).join('  ');

  const field =
  'w-full rounded-[3px] border border-graphite-600 bg-graphite-800 px-2 py-1.5 font-mono text-[11.5px] text-ink-100 focus:border-accent-500 focus:outline-none';
  const label =
  'block pb-1 font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-700';

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-graphite-900/80 p-6">
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Cadastrar equipamento genérico"
        className="w-[420px] rounded-[5px] border border-graphite-600 bg-graphite-850 shadow-2xl">
        
        <div className="flex items-start gap-2 border-b border-graphite-700 px-4 py-3">
          <div className="flex-1">
            <span className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-accent-400">
              {rack.name} · equipamento genérico
            </span>
            <h2 className="font-mono text-[13px] text-ink-100">
              Cadastrar equipamento
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar"
            className="rounded-[3px] border border-graphite-600 p-1 text-ink-500 transition-colors duration-150 ease-out hover:text-ink-100">
            
            <XIcon className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="space-y-3 px-4 py-4">
          <div>
            <label className={label} htmlFor="gen-name">
              Nome
            </label>
            <input
              id="gen-name"
              className={field}
              value={draft.name}
              onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
            
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className={label} htmlFor="gen-h">
                Altura (U)
              </label>
              <select
                id="gen-h"
                className={field}
                value={draft.heightU}
                onChange={(e) =>
                setDraft({ ...draft, heightU: Number(e.target.value) })
                }>
                
                {[1, 2, 3, 4].map((u) =>
                <option key={u} value={u}>
                    {u}U
                  </option>
                )}
              </select>
            </div>
            <div>
              <label className={label} htmlFor="gen-ports">
                Portas
              </label>
              <input
                id="gen-ports"
                type="number"
                min={1}
                max={48}
                className={field}
                value={draft.portCount}
                onChange={(e) =>
                setDraft({ ...draft, portCount: Number(e.target.value) })
                } />
              
            </div>
            <div>
              <label className={label} htmlFor="gen-u">
                Posição (U)
              </label>
              <input
                id="gen-u"
                type="number"
                min={1}
                max={RACK_U}
                className={field}
                value={draft.startU}
                onChange={(e) =>
                setDraft({ ...draft, startU: Number(e.target.value) })
                } />
              
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={label} htmlFor="gen-style">
                Numeração das portas
              </label>
              <select
                id="gen-style"
                className={field}
                value={draft.style}
                onChange={(e) =>
                setDraft({
                  ...draft,
                  style: e.target.value as PortNumberingStyle
                })
                }>
                
                {STYLES.map((s) =>
                <option key={s.id} value={s.id}>
                    {s.label}
                  </option>
                )}
              </select>
            </div>
            <div>
              <label className={label} htmlFor="gen-media">
                Mídia
              </label>
              <select
                id="gen-media"
                className={field}
                value={draft.media}
                onChange={(e) =>
                setDraft({
                  ...draft,
                  media: e.target.value as 'copper' | 'fiber'
                })
                }>
                
                <option value="copper">Metálica (RJ45)</option>
                <option value="fiber">Óptica</option>
              </select>
            </div>
          </div>

          <div className="rounded-[3px] border border-graphite-700 bg-graphite-800/60 px-2.5 py-2">
            <span className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-700">
              Preview do painel frontal
            </span>
            <p className="mt-1 truncate font-mono text-[10.5px] text-steel-300">
              {preview}
              {draft.portCount > 8 ? '  …' : ''}
            </p>
          </div>

          {conflict &&
          <p className="font-mono text-[10.5px] text-warn">{conflict}</p>
          }
        </div>

        <div className="flex justify-end gap-2 border-t border-graphite-700 px-4 py-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-[3px] border border-graphite-600 px-3 py-1.5 font-mono text-[11px] text-ink-300 transition-colors duration-150 ease-out hover:text-ink-100">
            
            Cancelar
          </button>
          <button
            type="button"
            disabled={!!conflict}
            onClick={() => onCreate(draft)}
            className="rounded-[3px] border border-accent-500 bg-accent-600/30 px-3 py-1.5 font-mono text-[11px] text-accent-200 transition-colors duration-150 ease-out hover:bg-accent-600/50 disabled:cursor-not-allowed disabled:opacity-40">
            
            Montar no rack
          </button>
        </div>
      </div>
    </div>);

}