import React from 'react';
import {
  PlusIcon,
  SearchIcon,
  ServerIcon,
  SlidersHorizontalIcon } from
'lucide-react';
import type {
  Connection,
  ConnectionFilters,
  Device,
  DeviceKind,
  DeviceTemplate,
  Pop,
  PortFilter,
  Rack,
  Selection } from
'../types/network';
import { KIND_LABEL } from '../data/templates';
import { KIND_STRIPE } from '../utils/style';
import { portKey } from '../utils/path';

interface Props {
  pops: Pop[];
  popId: string;
  onPop: (popId: string) => void;
  racks: Rack[];
  rackId: string;
  onRack: (rackId: string) => void;
  devices: Device[];
  templates: Record<string, DeviceTemplate>;
  connections: Connection[];
  query: string;
  onQuery: (q: string) => void;
  kindFilter: DeviceKind[];
  onToggleKind: (kind: DeviceKind) => void;
  filters: ConnectionFilters;
  onFilters: (filters: ConnectionFilters) => void;
  portFilter: PortFilter;
  onPortFilter: (f: PortFilter) => void;
  selection: Selection;
  onSelectDevice: (deviceId: string) => void;
  onAdd: () => void;
}

const KINDS: DeviceKind[] = [
'switch',
'router',
'olt',
'edd',
'dio',
'patch',
'generic'];


const SectionTitle = ({ children }: {children: React.ReactNode;}) =>
<h2 className="px-4 pb-1.5 pt-3 font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-700">
    {children}
  </h2>;


const Check = ({
  checked,
  label,
  onChange




}: {checked: boolean;label: string;onChange: () => void;}) =>
<label className="flex cursor-pointer items-center gap-2 py-[3px] font-mono text-[11px] text-ink-300 hover:text-ink-100">
    <input
    type="checkbox"
    checked={checked}
    onChange={onChange}
    className="h-3 w-3 shrink-0 cursor-pointer appearance-none rounded-[2px] border border-graphite-500 bg-graphite-800 checked:border-accent-500 checked:bg-accent-600/70" />
  
    {label}
  </label>;


export function Sidebar({
  pops,
  popId,
  onPop,
  racks,
  rackId,
  onRack,
  devices,
  templates,
  connections,
  query,
  onQuery,
  kindFilter,
  onToggleKind,
  filters,
  onFilters,
  portFilter,
  onPortFilter,
  selection,
  onSelectDevice,
  onAdd
}: Props) {
  const selectedDeviceId =
  selection.kind === 'device' || selection.kind === 'port' ?
  selection.deviceId :
  undefined;

  const visibleDevices = devices.
  filter((d) => {
    if (d.rackId !== rackId) return false;
    const tpl = templates[d.templateId];
    if (!tpl) return false;
    if (kindFilter.length > 0 && !kindFilter.includes(tpl.kind)) return false;
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    if (d.name.toLowerCase().includes(q)) return true;
    if (`${tpl.vendor} ${tpl.model}`.toLowerCase().includes(q)) return true;
    return tpl.groups.some((g) =>
    g.ports.some((p) => p.name.toLowerCase().includes(q))
    );
  }).
  sort((a, b) => b.startU - a.startU);

  const usedPorts = (device: Device, tpl: DeviceTemplate) => {
    const total = tpl.groups.reduce((n, g) => n + g.ports.length, 0);
    const used = tpl.groups.
    flatMap((g) => g.ports).
    filter((p) =>
    connections.some(
      (c) =>
      portKey(c.a.deviceId, c.a.portId) === portKey(device.id, p.id) ||
      portKey(c.b.deviceId, c.b.portId) === portKey(device.id, p.id)
    )
    ).length;
    return { used, total };
  };

  return (
    <aside className="flex w-[292px] shrink-0 flex-col overflow-hidden border-r border-graphite-700 bg-graphite-850">
      <div className="border-b border-graphite-700 px-4 py-3">
        <label
          htmlFor="pop-select"
          className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-700">
          
          Point of presence
        </label>
        <select
          id="pop-select"
          value={popId}
          onChange={(e) => onPop(e.target.value)}
          className="mt-1.5 w-full cursor-pointer rounded-[3px] border border-graphite-600 bg-graphite-800 px-2 py-1.5 font-mono text-[12px] text-ink-100 focus:border-accent-500 focus:outline-none">
          
          {pops.map((p) =>
          <option key={p.id} value={p.id}>
              {p.name} · {p.city}
            </option>
          )}
        </select>
      </div>

      <SectionTitle>Racks</SectionTitle>
      <nav className="px-2" aria-label="Racks">
        {racks.map((r) => {
          const count = devices.filter((d) => d.rackId === r.id).length;
          const active = r.id === rackId;
          return (
            <button
              key={r.id}
              type="button"
              aria-current={active}
              onClick={() => onRack(r.id)}
              className={`flex w-full items-center gap-2 rounded-[3px] px-2 py-1.5 text-left transition-colors duration-150 ease-out ${
              active ?
              'bg-accent-600/20 text-ink-100 ring-1 ring-accent-500/40' :
              'text-ink-300 hover:bg-graphite-800'}`
              }>
              
              <ServerIcon
                className={`h-3.5 w-3.5 ${active ? 'text-accent-400' : 'text-ink-700'}`} />
              
              <span className="font-mono text-[11.5px]">{r.name}</span>
              <span className="ml-auto font-mono text-[10px] text-ink-700">
                {r.units}U
                {active ? ` · ${count}` : ''}
              </span>
            </button>);

        })}
      </nav>

      <div className="mt-3 border-y border-graphite-700 px-4 py-2.5">
        <div className="relative">
          <SearchIcon className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-700" />
          <input
            type="search"
            value={query}
            onChange={(e) => onQuery(e.target.value)}
            placeholder="Device, model or port…"
            aria-label="Search devices and ports"
            className="w-full rounded-[3px] border border-graphite-600 bg-graphite-800 py-1.5 pl-7 pr-2 font-mono text-[11.5px] text-ink-100 placeholder:text-ink-700 focus:border-accent-500 focus:outline-none" />
          
        </div>
        <div className="mt-2 flex flex-wrap gap-1">
          {KINDS.map((k) => {
            const active = kindFilter.includes(k);
            return (
              <button
                key={k}
                type="button"
                aria-pressed={active}
                onClick={() => onToggleKind(k)}
                className={`flex items-center gap-1 rounded-[3px] border px-1.5 py-[2px] font-mono text-[9.5px] transition-colors duration-150 ease-out ${
                active ?
                'border-accent-500/60 bg-accent-600/20 text-accent-300' :
                'border-graphite-600 text-ink-500 hover:text-ink-300'}`
                }>
                
                <i className={`h-1.5 w-1.5 rounded-full ${KIND_STRIPE[k]}`} />
                {KIND_LABEL[k]}
              </button>);

          })}
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto rack-scroll">
        <div className="flex items-center justify-between pr-2">
          <SectionTitle>Mounted equipment</SectionTitle>
          <button
            type="button"
            onClick={onAdd}
            className="mt-2 flex items-center gap-1 rounded-[3px] border border-graphite-600 px-1.5 py-[3px] font-mono text-[9.5px] text-ink-300 transition-colors duration-150 ease-out hover:border-accent-500/60 hover:text-accent-300">
            
            <PlusIcon className="h-3 w-3" />
            Generic
          </button>
        </div>
        <ul className="px-2 pb-4">
          {visibleDevices.map((d) => {
            const tpl = templates[d.templateId];
            const { used, total } = usedPorts(d, tpl);
            const active = d.id === selectedDeviceId;
            return (
              <li key={d.id}>
                <button
                  type="button"
                  onClick={() => onSelectDevice(d.id)}
                  className={`mb-0.5 flex w-full items-center gap-2 rounded-[3px] border px-2 py-1.5 text-left transition-colors duration-150 ease-out ${
                  active ?
                  'border-accent-500/50 bg-accent-600/15' :
                  'border-transparent hover:border-graphite-600 hover:bg-graphite-800'}`
                  }>
                  
                  <i className={`h-6 w-[3px] shrink-0 rounded-full ${KIND_STRIPE[tpl.kind]}`} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-mono text-[11px] text-ink-100">
                      {d.name}
                    </span>
                    <span className="block truncate font-mono text-[9.5px] text-ink-500">
                      {tpl.model} · {used}/{total} ports
                    </span>
                  </span>
                  <span className="shrink-0 font-mono text-[9.5px] text-ink-700">
                    U{d.startU}
                    {tpl.heightU > 1 ? `–${d.startU + tpl.heightU - 1}` : ''}
                  </span>
                </button>
              </li>);

          })}
          {visibleDevices.length === 0 &&
          <li className="px-2 py-4 font-mono text-[11px] text-ink-700">
              No equipment matches this filter.
            </li>
          }
        </ul>
      </div>

      <div className="border-t border-graphite-700 px-4 py-3">
        <h2 className="flex items-center gap-1.5 pb-1.5 font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-700">
          <SlidersHorizontalIcon className="h-3 w-3" />
          Connection filters
        </h2>
        <Check
          checked={filters.sameRack}
          label="Same rack"
          onChange={() => onFilters({ ...filters, sameRack: !filters.sameRack })} />
        
        <Check
          checked={filters.crossRack}
          label="Between racks"
          onChange={() => onFilters({ ...filters, crossRack: !filters.crossRack })} />
        
        <Check
          checked={filters.fiber}
          label="Fiber"
          onChange={() => onFilters({ ...filters, fiber: !filters.fiber })} />
        
        <Check
          checked={filters.ethernet}
          label="Ethernet / data"
          onChange={() => onFilters({ ...filters, ethernet: !filters.ethernet })} />
        
        <div className="mt-2.5 flex rounded-[3px] border border-graphite-600 bg-graphite-800 p-0.5">
          {(['all', 'connected', 'free'] as PortFilter[]).map((f) =>
          <button
            key={f}
            type="button"
            aria-pressed={portFilter === f}
            onClick={() => onPortFilter(f)}
            className={`flex-1 rounded-[2px] py-1 font-mono text-[10px] capitalize transition-colors duration-150 ease-out ${
            portFilter === f ?
            'bg-graphite-700 text-ink-100' :
            'text-ink-500 hover:text-ink-300'}`
            }>
            
              {f === 'all' ? 'All ports' : `${f} ports`}
            </button>
          )}
        </div>
      </div>
    </aside>);

}