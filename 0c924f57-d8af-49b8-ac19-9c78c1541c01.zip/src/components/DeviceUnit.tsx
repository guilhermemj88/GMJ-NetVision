import React from 'react';
import type {
  Device,
  DeviceTemplate,
  LinkStatus,
  LinkType,
  PortFilter } from
'../types/network';
import { KIND_LABEL } from '../data/templates';
import { KIND_STRIPE, KIND_TEXT } from '../utils/style';
import {
  DEVICE_W,
  DEVICE_X,
  U_H,
  deviceBoxTop,
  portPoint,
  portRects } from
'../utils/geometry';

export interface PortTooltip {
  x: number;
  y: number;
  label: string;
  sub: string;
  status?: LinkStatus;
}

interface Props {
  device: Device;
  tpl: DeviceTemplate;
  state: 'selected' | 'related' | 'normal' | 'dim';
  selectedPortId?: string;
  highlightedPorts: Set<string>;
  portLinks: Map<string, {status: LinkStatus;type: LinkType;remote: string;}>;
  portFilter: PortFilter;
  onSelectDevice: (deviceId: string) => void;
  onSelectPort: (deviceId: string, portId: string) => void;
  onHoverPort: (tip: PortTooltip | null) => void;
}

const portClass = (args: {
  selected: boolean;
  highlighted: boolean;
  link?: {status: LinkStatus;};
  fiber: boolean;
  muted: boolean;
}) => {
  const shape = args.fiber ? 'rounded-full' : 'rounded-[1px]';
  if (args.selected)
  return `${shape} bg-accent-500 border border-accent-300 ring-2 ring-accent-500/50 z-20`;
  if (args.highlighted)
  return `${shape} bg-accent-500/70 border border-accent-300 z-20`;
  if (args.muted)
  return `${shape} border border-graphite-600 bg-graphite-800/60 opacity-40`;
  if (!args.link)
  return `${shape} border border-graphite-500 bg-graphite-800 hover:border-steel-400`;
  if (args.link.status === 'down')
  return `${shape} border border-crit/80 bg-crit/25 hover:border-crit`;
  if (args.link.status === 'degraded')
  return `${shape} border border-warn/80 bg-warn/20 hover:border-warn`;
  return `${shape} border border-ok/60 bg-ok/20 hover:border-ok`;
};

export function DeviceUnit({
  device,
  tpl,
  state,
  selectedPortId,
  highlightedPorts,
  portLinks,
  portFilter,
  onSelectDevice,
  onSelectPort,
  onHoverPort
}: Props) {
  const rects = portRects(tpl);
  const top = deviceBoxTop(device.startU, tpl.heightU);
  const height = tpl.heightU * U_H - 2;
  const uLabel =
  tpl.heightU > 1 ?
  `U${device.startU}–U${device.startU + tpl.heightU - 1}` :
  `U${device.startU}`;

  const frame =
  state === 'selected' ?
  'border-accent-500 bg-graphite-750 shadow-[0_0_0_1px_rgba(139,92,246,0.45),0_0_22px_-6px_rgba(139,92,246,0.55)]' :
  state === 'related' ?
  'border-steel-600 bg-graphite-750' :
  state === 'dim' ?
  'border-graphite-600/60 bg-graphite-800/70 opacity-45' :
  'border-graphite-600 bg-graphite-800 hover:border-graphite-500';

  return (
    <div
      className="absolute"
      style={{ left: DEVICE_X, top, width: DEVICE_W, height }}>
      
      <div
        role="button"
        tabIndex={0}
        aria-label={`${device.name}, ${uLabel}`}
        onClick={() => onSelectDevice(device.id)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onSelectDevice(device.id);
          }
        }}
        className={`absolute inset-0 cursor-pointer overflow-hidden rounded-[3px] border transition-colors duration-150 ease-out focus:outline-none focus-visible:ring-2 focus-visible:ring-accent-500/70 ${frame}`}>
        
        <span
          className={`absolute left-0 top-0 h-full w-[3px] ${KIND_STRIPE[tpl.kind]} ${state === 'dim' ? 'opacity-50' : ''}`} />
        
        {/* Nameplate */}
        <div className="absolute inset-y-0 left-[3px] flex w-[130px] flex-col justify-center border-r border-graphite-600/70 px-2">
          <span className="truncate font-mono text-[10.5px] leading-tight text-ink-100">
            {device.name}
          </span>
          <span className="truncate text-[8.5px] leading-tight text-ink-500">
            {tpl.vendor} {tpl.model}
          </span>
          {tpl.heightU > 1 &&
          <span
            className={`mt-1 w-fit rounded-sm border border-graphite-600 px-1 text-[8px] uppercase tracking-wider ${KIND_TEXT[tpl.kind]}`}>
            
              {KIND_LABEL[tpl.kind]}
            </span>
          }
        </div>

        {/* Group labels (only where vertical room exists) */}
        {tpl.heightU > 1 &&
        tpl.groups.map((g) =>
        g.label ?
        <span
          key={g.id}
          className="absolute font-mono text-[8px] uppercase tracking-wide text-ink-700"
          style={{ left: g.x, top: Math.max(2, g.y - 11) }}>
          
                {g.label}
              </span> :
        null
        )}

        <span className="absolute right-2 top-1 font-mono text-[9px] text-ink-700">
          {uLabel}
        </span>

        {/* Ports */}
        {rects.map((rect) => {
          const link = portLinks.get(rect.id);
          const selected = selectedPortId === rect.id;
          const highlighted = highlightedPorts.has(rect.id);
          const muted =
          state === 'dim' ||
          portFilter === 'connected' && !link ||
          portFilter === 'free' && !!link;
          return (
            <button
              key={rect.id}
              type="button"
              aria-label={`${device.name} port ${rect.name}${link ? `, connected to ${link.remote}` : ', free'}`}
              onClick={(e) => {
                e.stopPropagation();
                onSelectPort(device.id, rect.id);
              }}
              onMouseEnter={() => {
                const pt = portPoint(device, tpl, rect.id);
                if (!pt) return;
                onHoverPort({
                  x: pt.cx,
                  y: top - 2,
                  label: `${device.name} · ${rect.name}`,
                  sub: link ? `→ ${link.remote}` : 'Porta livre',
                  status: link?.status
                });
              }}
              onMouseLeave={() => onHoverPort(null)}
              className={`absolute transition-colors duration-150 ease-out focus:outline-none focus-visible:ring-2 focus-visible:ring-accent-400 ${portClass(
                { selected, highlighted, link, fiber: rect.media === 'fiber', muted }
              )}`}
              style={{ left: rect.x, top: rect.y, width: rect.w, height: rect.h }} />);


        })}
      </div>
    </div>);

}