import type {
  Connection,
  Device,
  DeviceKind,
  DeviceTemplate,
  Endpoint,
  LinkStatus,
  LinkType,
  RearLink } from
'../types/network';

export const portKey = (deviceId: string, portId: string) =>
`${deviceId}:${portId}`;

export interface PathNode {
  kind: 'node';
  deviceName: string;
  deviceKind: DeviceKind | 'external';
  portName: string;
  note?: string;
  passthrough?: boolean;
  deviceId?: string;
  portId?: string;
}

export interface PathLink {
  kind: 'link';
  type: LinkType;
  status?: LinkStatus;
  label: string;
}

export type PathItem = PathNode | PathLink;

interface Ctx {
  devices: Device[];
  templates: Record<string, DeviceTemplate>;
  connections: Connection[];
  rearLinks: Record<string, RearLink>;
}

export function findConnectionForPort(
connections: Connection[],
deviceId: string,
portId: string)
: Connection | undefined {
  return connections.find(
    (c) =>
    c.a.deviceId === deviceId && c.a.portId === portId ||
    c.b.deviceId === deviceId && c.b.portId === portId
  );
}

export function otherEnd(conn: Connection, ep: Endpoint): Endpoint {
  return conn.a.deviceId === ep.deviceId && conn.a.portId === ep.portId ?
  conn.b :
  conn.a;
}

function nodeFor(ep: Endpoint, ctx: Ctx): PathNode {
  const device = ctx.devices.find((d) => d.id === ep.deviceId);
  const tpl = device ? ctx.templates[device.templateId] : undefined;
  return {
    kind: 'node',
    deviceName: device?.name ?? ep.deviceId,
    deviceKind: tpl?.kind ?? 'external',
    portName: ep.portId,
    passthrough: tpl?.passthrough,
    deviceId: ep.deviceId,
    portId: ep.portId
  };
}

/**
 * Walks the physical path from one endpoint, continuing through the rear side
 * of any DIO / patch panel it lands on.
 */
export function tracePath(start: Endpoint, ctx: Ctx): PathItem[] {
  const conn = findConnectionForPort(
    ctx.connections,
    start.deviceId,
    start.portId
  );
  if (!conn) return [nodeFor(start, ctx)];

  const far = otherEnd(conn, start);
  const items: PathItem[] = [
  nodeFor(start, ctx),
  {
    kind: 'link',
    type: conn.type,
    status: conn.status,
    label: conn.type === 'fiber' ? 'Cordão óptico' : 'Patch cord UTP'
  },
  nodeFor(far, ctx)];


  const rear = ctx.rearLinks[portKey(far.deviceId, far.portId)];
  const farDevice = ctx.devices.find((d) => d.id === far.deviceId);
  const farTpl = farDevice ? ctx.templates[farDevice.templateId] : undefined;
  if (rear && farTpl?.passthrough) {
    items.push({ kind: 'link', type: rear.type, label: rear.label });
    rear.chain.forEach((hop, i) => {
      items.push({
        kind: 'node',
        deviceName: hop.device,
        deviceKind: 'external',
        portName: hop.port,
        note: hop.note
      });
      if (i < rear.chain.length - 1) {
        items.push({
          kind: 'link',
          type: rear.type,
          label: 'Continuação do lance'
        });
      }
    });
  }
  return items;
}