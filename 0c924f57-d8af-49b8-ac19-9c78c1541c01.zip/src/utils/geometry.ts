import type { Device, DeviceTemplate, PortMedia } from '../types/network';

export const RACK_U = 42;
export const U_H = 30;
export const RAIL_W = 40;
export const DEVICE_X = 52;
export const DEVICE_W = 580;
export const LANE_X = DEVICE_X + DEVICE_W + 16;
export const LANE_W = 152;
export const CANVAS_W = LANE_X + LANE_W;
export const CANVAS_H = RACK_U * U_H;

/** Absolutely positioned ports sit inside the device box border (1px) + 1px inset. */
export const PORT_OX = 1;
export const PORT_OY = 2;

export interface PortRect {
  id: string;
  name: string;
  media: PortMedia;
  groupId: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

const rectCache = new Map<string, PortRect[]>();
const mapCache = new Map<string, Map<string, PortRect>>();

export function portRects(tpl: DeviceTemplate): PortRect[] {
  const cached = rectCache.get(tpl.id);
  if (cached) return cached;
  const out: PortRect[] = [];
  for (const g of tpl.groups) {
    const gapY = g.gapY ?? 4;
    g.ports.forEach((port, i) => {
      const col = g.mode === 'stacked2' ? Math.floor(i / 2) : i;
      const row = g.mode === 'stacked2' ? i % 2 : 0;
      out.push({
        id: port.id,
        name: port.name,
        media: port.media,
        groupId: g.id,
        x: g.x + col * (g.portW + g.gapX),
        y: g.y + row * (g.portH + gapY),
        w: g.portW,
        h: g.portH
      });
    });
  }
  rectCache.set(tpl.id, out);
  return out;
}

export function portRectMap(tpl: DeviceTemplate): Map<string, PortRect> {
  const cached = mapCache.get(tpl.id);
  if (cached) return cached;
  const map = new Map(portRects(tpl).map((r) => [r.id, r]));
  mapCache.set(tpl.id, map);
  return map;
}

export function deviceTopY(startU: number, heightU: number): number {
  return (RACK_U - (startU + heightU - 1)) * U_H;
}

export function deviceBoxTop(startU: number, heightU: number): number {
  return deviceTopY(startU, heightU) + 1;
}

export interface PortPoint {
  cx: number;
  cy: number;
  left: number;
  right: number;
}

export function portPoint(
device: Device,
tpl: DeviceTemplate,
portId: string)
: PortPoint | null {
  const rect = portRectMap(tpl).get(portId);
  if (!rect) return null;
  const top = deviceTopY(device.startU, tpl.heightU);
  const x = DEVICE_X + PORT_OX + rect.x;
  const y = top + PORT_OY + rect.y;
  return {
    cx: x + rect.w / 2,
    cy: y + rect.h / 2,
    left: x,
    right: x + rect.w
  };
}

const R = 8;

/** Port → vertical cable lane → port. Keeps cables out of the rack body. */
export function cablePath(
x0: number,
y0: number,
x1: number,
y1: number,
laneX: number)
: string {
  const dy = y1 - y0;
  if (Math.abs(dy) < 2 * R + 6) {
    return `M ${x0} ${y0} C ${laneX} ${y0} ${laneX} ${y1} ${x1} ${y1}`;
  }
  const s = Math.sign(dy);
  return [
  `M ${x0} ${y0}`,
  `L ${laneX - R} ${y0}`,
  `Q ${laneX} ${y0} ${laneX} ${y0 + s * R}`,
  `L ${laneX} ${y1 - s * R}`,
  `Q ${laneX} ${y1} ${laneX - R} ${y1}`,
  `L ${x1} ${y1}`].
  join(' ');
}

/** Port → lane → out of the rack (other rack, other POP, outside plant). */
export function exitPath(
x0: number,
y0: number,
laneX: number,
exitY: number,
xEnd: number)
: string {
  const dy = exitY - y0;
  if (Math.abs(dy) < 2 * R + 6) {
    return `M ${x0} ${y0} C ${laneX} ${y0} ${laneX} ${exitY} ${xEnd} ${exitY}`;
  }
  const s = Math.sign(dy);
  return [
  `M ${x0} ${y0}`,
  `L ${laneX - R} ${y0}`,
  `Q ${laneX} ${y0} ${laneX} ${y0 + s * R}`,
  `L ${laneX} ${exitY - s * R}`,
  `Q ${laneX} ${exitY} ${laneX + R} ${exitY}`,
  `L ${xEnd} ${exitY}`].
  join(' ');
}

export const TRACK_COUNT = 11;
export const TRACK_GAP = 11;
export const TRACK_X0 = LANE_X + 14;

export function trackX(track: number): number {
  return TRACK_X0 + track % TRACK_COUNT * TRACK_GAP;
}

/**
 * Greedy interval colouring so cables sharing a lane never overlap vertically.
 * Produces tidy parallel runs instead of random crossings.
 */
export function assignTracks(
items: {id: string;y0: number;y1: number;}[])
: Record<string, number> {
  const sorted = [...items].sort(
    (a, b) => Math.min(a.y0, a.y1) - Math.min(b.y0, b.y1)
  );
  const laneEnds: number[] = [];
  const out: Record<string, number> = {};
  for (const it of sorted) {
    const top = Math.min(it.y0, it.y1) - 6;
    const bottom = Math.max(it.y0, it.y1) + 6;
    let track = laneEnds.findIndex((end) => end <= top);
    if (track === -1) {
      track = laneEnds.length;
      laneEnds.push(bottom);
    } else {
      laneEnds[track] = bottom;
    }
    out[it.id] = track;
  }
  return out;
}