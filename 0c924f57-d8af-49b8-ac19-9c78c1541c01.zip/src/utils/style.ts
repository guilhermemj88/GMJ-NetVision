import type { DeviceKind, LinkStatus } from '../types/network';

export const KIND_STRIPE: Record<DeviceKind, string> = {
  switch: 'bg-steel-400',
  router: 'bg-accent-400',
  olt: 'bg-steel-500',
  edd: 'bg-ink-500',
  dio: 'bg-ok',
  patch: 'bg-ink-700',
  generic: 'bg-warn'
};

export const KIND_TEXT: Record<DeviceKind, string> = {
  switch: 'text-steel-300',
  router: 'text-accent-400',
  olt: 'text-steel-400',
  edd: 'text-ink-300',
  patch: 'text-ink-500',
  dio: 'text-ok',
  generic: 'text-warn'
};

export const STATUS_DOT: Record<LinkStatus, string> = {
  connected: 'bg-ok',
  degraded: 'bg-warn',
  down: 'bg-crit'
};

export const STATUS_LABEL: Record<LinkStatus, string> = {
  connected: 'Connected',
  degraded: 'Degraded',
  down: 'Down'
};

export const STATUS_STROKE: Record<LinkStatus, string> = {
  connected: '#8b5cf6',
  degraded: '#f59e0b',
  down: '#f43f5e'
};