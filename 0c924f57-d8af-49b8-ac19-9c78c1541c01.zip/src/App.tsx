import React, { useEffect, useMemo, useState } from 'react';
import type {
  ConnectionFilters,
  Device,
  DeviceKind,
  DeviceTemplate,
  PortFilter,
  Selection } from
'./types/network';
import { BASE_TEMPLATES, makeGenericTemplate } from './data/templates';
import { CONNECTIONS, INITIAL_DEVICES, POPS, RACKS, REAR_LINKS } from './data/pop';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { RackCanvas } from './components/RackCanvas';
import { DetailDrawer } from './components/DetailDrawer';
import {
  AddEquipmentDialog,
  type GenericDraft } from
'./components/AddEquipmentDialog';

type ConnectionModeProp = 'hidden' | 'selected' | 'all';

interface AppProps {
  /** Default connection visibility in the rack view. */
  connectionMode?: ConnectionModeProp;
  /** Which ports the rack emphasises when nothing is selected. */
  portEmphasis?: 'all' | 'connected' | 'free';
}

export function App({
  connectionMode = 'selected',
  portEmphasis = 'all'
}: AppProps) {
  const [popId, setPopId] = useState('pop-jardim');
  const [rackId, setRackId] = useState('rack-01');
  const [devices, setDevices] = useState<Device[]>(INITIAL_DEVICES);
  const [templates, setTemplates] =
  useState<Record<string, DeviceTemplate>>(BASE_TEMPLATES);
  const [selection, setSelection] = useState<Selection>({
    kind: 'port',
    deviceId: 'sw-s6730-01',
    portId: 'GE0/0/10'
  });
  const [mode, setMode] = useState<ConnectionModeProp>(connectionMode);
  const [filters, setFilters] = useState<ConnectionFilters>({
    fiber: true,
    ethernet: true,
    sameRack: true,
    crossRack: true
  });
  const [portFilter, setPortFilter] = useState<PortFilter>(portEmphasis);
  const [query, setQuery] = useState('');
  const [kindFilter, setKindFilter] = useState<DeviceKind[]>([]);
  const [zoom, setZoom] = useState(1);
  const [dialogOpen, setDialogOpen] = useState(false);

  const pop = POPS.find((p) => p.id === popId) ?? POPS[0];
  const popRacks = RACKS.filter((r) => r.popId === popId);
  const rack = popRacks.find((r) => r.id === rackId) ?? popRacks[0];

  const rackDeviceCount = useMemo(
    () => devices.filter((d) => d.rackId === rack.id).length,
    [devices, rack.id]
  );
  const rackLinkCount = useMemo(() => {
    const ids = new Set(devices.filter((d) => d.rackId === rack.id).map((d) => d.id));
    return CONNECTIONS.filter(
      (c) => ids.has(c.a.deviceId) || ids.has(c.b.deviceId)
    ).length;
  }, [devices, rack.id]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      if (dialogOpen) setDialogOpen(false);else
      setSelection({ kind: 'none' });
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [dialogOpen]);

  const handlePop = (next: string) => {
    setPopId(next);
    const first = RACKS.find((r) => r.popId === next);
    if (first) setRackId(first.id);
    setSelection({ kind: 'none' });
  };

  const handleCreate = (draft: GenericDraft) => {
    const id = `generic-${Date.now()}`;
    const tpl = makeGenericTemplate({
      id,
      model: `Generic ${draft.heightU}U · ${draft.portCount}P`,
      heightU: draft.heightU,
      portCount: draft.portCount,
      style: draft.style,
      media: draft.media
    });
    setTemplates((prev) => ({ ...prev, [id]: tpl }));
    const device: Device = {
      id: `dev-${id}`,
      name: draft.name.trim(),
      templateId: id,
      rackId: rack.id,
      startU: draft.startU,
      note: 'Equipamento genérico cadastrado pelo NOC'
    };
    setDevices((prev) => [...prev, device]);
    setSelection({ kind: 'device', deviceId: device.id });
    setDialogOpen(false);
  };

  return (
    <div className="relative flex h-screen w-full flex-col overflow-hidden bg-graphite-900 font-sans text-ink-100">
      <TopBar
        pop={pop}
        rack={rack}
        deviceCount={rackDeviceCount}
        connectionCount={rackLinkCount}
        mode={mode}
        onMode={setMode}
        zoom={zoom}
        onZoom={setZoom} />
      
      <div className="flex min-h-0 flex-1">
        <Sidebar
          pops={POPS}
          popId={popId}
          onPop={handlePop}
          racks={popRacks}
          rackId={rack.id}
          onRack={(id) => {
            setRackId(id);
            setSelection({ kind: 'none' });
          }}
          devices={devices}
          templates={templates}
          connections={CONNECTIONS}
          query={query}
          onQuery={setQuery}
          kindFilter={kindFilter}
          onToggleKind={(k) =>
          setKindFilter((prev) =>
          prev.includes(k) ? prev.filter((x) => x !== k) : [...prev, k]
          )
          }
          filters={filters}
          onFilters={setFilters}
          portFilter={portFilter}
          onPortFilter={setPortFilter}
          selection={selection}
          onSelectDevice={(id) => setSelection({ kind: 'device', deviceId: id })}
          onAdd={() => setDialogOpen(true)} />
        
        <RackCanvas
          rack={rack}
          racks={RACKS}
          devices={devices}
          templates={templates}
          connections={CONNECTIONS}
          rearLinks={REAR_LINKS}
          filters={filters}
          mode={mode}
          selection={selection}
          portFilter={portFilter}
          zoom={zoom}
          onSelectDevice={(id) => setSelection({ kind: 'device', deviceId: id })}
          onSelectPort={(deviceId, portId) =>
          setSelection({ kind: 'port', deviceId, portId })
          }
          onSelectConnection={(id) =>
          setSelection({ kind: 'connection', connectionId: id })
          }
          onClear={() => setSelection({ kind: 'none' })} />
        
        <DetailDrawer
          selection={selection}
          devices={devices}
          templates={templates}
          connections={CONNECTIONS}
          rearLinks={REAR_LINKS}
          onSelectPort={(deviceId, portId) =>
          setSelection({ kind: 'port', deviceId, portId })
          }
          onSelectDevice={(id) => setSelection({ kind: 'device', deviceId: id })}
          onClear={() => setSelection({ kind: 'none' })} />
        
      </div>
      <AddEquipmentDialog
        open={dialogOpen}
        rack={rack}
        devices={devices}
        templates={templates}
        onClose={() => setDialogOpen(false)}
        onCreate={handleCreate} />
      
    </div>);

}