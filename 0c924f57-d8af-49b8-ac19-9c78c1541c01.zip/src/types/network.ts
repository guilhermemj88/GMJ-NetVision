export type DeviceKind =
'switch' |
'router' |
'olt' |
'edd' |
'dio' |
'patch' |
'generic';

export type PortMedia = 'copper' | 'fiber' | 'console';

export type LinkType = 'fiber' | 'ethernet';

export type LinkStatus = 'connected' | 'degraded' | 'down';

export type PortNumberingStyle = 'numeric' | 'padded' | 'lan' | 'port';

export interface PortDef {
  id: string;
  name: string;
  media: PortMedia;
}

export interface PortGroupDef {
  id: string;
  label?: string;
  mode: 'single' | 'stacked2';
  x: number;
  y: number;
  portW: number;
  portH: number;
  gapX: number;
  gapY?: number;
  ports: PortDef[];
}

export interface DeviceTemplate {
  id: string;
  vendor: string;
  model: string;
  kind: DeviceKind;
  heightU: number;
  /** DIOs and patch panels terminate a front port and continue on the rear side. */
  passthrough?: boolean;
  groups: PortGroupDef[];
}

export interface Device {
  id: string;
  name: string;
  templateId: string;
  rackId: string;
  /** Bottom-most rack unit occupied by the device. */
  startU: number;
  note?: string;
}

export interface Rack {
  id: string;
  popId: string;
  name: string;
  units: number;
  room: string;
}

export interface Pop {
  id: string;
  name: string;
  code: string;
  city: string;
}

export interface Endpoint {
  deviceId: string;
  portId: string;
}

export interface Connection {
  id: string;
  type: LinkType;
  status: LinkStatus;
  a: Endpoint;
  b: Endpoint;
  circuit?: string;
}

export interface ExternalHop {
  device: string;
  port: string;
  note?: string;
}

/** What happens on the rear side of a DIO / patch-panel port. */
export interface RearLink {
  label: string;
  type: LinkType;
  chain: ExternalHop[];
}

export type Selection =
{kind: 'none';} |
{kind: 'device';deviceId: string;} |
{kind: 'port';deviceId: string;portId: string;} |
{kind: 'connection';connectionId: string;};

export type ConnectionMode = 'hidden' | 'selected' | 'all';

export type PortFilter = 'all' | 'connected' | 'free';

export interface ConnectionFilters {
  fiber: boolean;
  ethernet: boolean;
  sameRack: boolean;
  crossRack: boolean;
}