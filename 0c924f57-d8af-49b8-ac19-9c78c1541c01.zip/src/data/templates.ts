import type {
  DeviceTemplate,
  PortDef,
  PortMedia,
  PortNumberingStyle } from
'../types/network';

const p = (name: string, media: PortMedia = 'copper'): PortDef => ({
  id: name,
  name,
  media
});

const range = (n: number, fn: (i: number) => PortDef) =>
Array.from({ length: n }, (_, i) => fn(i));

const pad = (n: number) => String(n).padStart(2, '0');

/** Huawei S6730-H48X6C — 48x GE access + 6x 10GE SFP+ uplink, 1U. */
const s6730: DeviceTemplate = {
  id: 'huawei-s6730',
  vendor: 'Huawei',
  model: 'S6730-H48X6C',
  kind: 'switch',
  heightU: 1,
  groups: [
  {
    id: 'access',
    label: 'GE0/0/1-48',
    mode: 'stacked2',
    x: 146,
    y: 2,
    portW: 8,
    portH: 9,
    gapX: 2,
    gapY: 4,
    ports: range(48, (i) => p(`GE0/0/${i + 1}`))
  },
  {
    id: 'uplink',
    label: '10GE SFP+',
    mode: 'stacked2',
    x: 400,
    y: 2,
    portW: 17,
    portH: 9,
    gapX: 3,
    gapY: 4,
    ports: range(6, (i) => p(`10GE1/0/${45 + i}`, 'fiber'))
  },
  {
    id: 'mgmt',
    mode: 'single',
    x: 480,
    y: 8,
    portW: 14,
    portH: 9,
    gapX: 4,
    ports: [p('MEth0/0/1')]
  }]

};

/** Datacom EDD — customer demarcation device, few interfaces, 1U. */
const eddDatacom: DeviceTemplate = {
  id: 'datacom-edd',
  vendor: 'Datacom',
  model: 'DM1000 EDD',
  kind: 'edd',
  heightU: 1,
  groups: [
  {
    id: 'lan',
    label: 'LAN',
    mode: 'single',
    x: 146,
    y: 7,
    portW: 20,
    portH: 12,
    gapX: 5,
    ports: range(6, (i) => p(`LAN${i + 1}`))
  },
  {
    id: 'wan',
    label: 'SFP',
    mode: 'single',
    x: 310,
    y: 7,
    portW: 22,
    portH: 12,
    gapX: 5,
    ports: range(2, (i) => p(`WAN${i + 1}`, 'fiber'))
  }]

};

/** Huawei NE8000 M4 — 4U edge router, two line cards. */
const ne8000: DeviceTemplate = {
  id: 'huawei-ne8000',
  vendor: 'Huawei',
  model: 'NE8000 M4',
  kind: 'router',
  heightU: 4,
  groups: [
  {
    id: 'slot1',
    label: 'Slot 1 · 100GE QSFP28',
    mode: 'single',
    x: 146,
    y: 30,
    portW: 26,
    portH: 15,
    gapX: 6,
    ports: range(8, (i) => p(`100GE1/0/${i + 1}`, 'fiber'))
  },
  {
    id: 'slot2',
    label: 'Slot 2 · 10GE SFP+',
    mode: 'stacked2',
    x: 146,
    y: 70,
    portW: 18,
    portH: 13,
    gapX: 4,
    gapY: 5,
    ports: range(12, (i) => p(`10GE2/0/${i + 1}`, 'fiber'))
  },
  {
    id: 'mpu',
    label: 'MPU',
    mode: 'single',
    x: 430,
    y: 30,
    portW: 20,
    portH: 13,
    gapX: 4,
    ports: [p('MEth0/0/0'), p('CON', 'console')]
  }]

};

/** Huawei MA5800-X2 OLT — 16 GPON + 2 uplink, 2U. */
const olt: DeviceTemplate = {
  id: 'huawei-olt',
  vendor: 'Huawei',
  model: 'MA5800-X2',
  kind: 'olt',
  heightU: 2,
  groups: [
  {
    id: 'pon',
    label: 'GPON 0/1/0-15',
    mode: 'stacked2',
    x: 146,
    y: 14,
    portW: 13,
    portH: 11,
    gapX: 3,
    gapY: 5,
    ports: range(16, (i) => p(`0/1/${i}`, 'fiber'))
  },
  {
    id: 'uplink',
    label: 'Uplink',
    mode: 'single',
    x: 300,
    y: 16,
    portW: 22,
    portH: 12,
    gapX: 5,
    ports: range(2, (i) => p(`0/9/${i}`, 'fiber'))
  }]

};

/** DIO 24F — optical distribution frame, 2U, 24 adapters. */
const dio24: DeviceTemplate = {
  id: 'dio-24f',
  vendor: 'Furukawa',
  model: 'DIO 24F SC/APC',
  kind: 'dio',
  heightU: 2,
  passthrough: true,
  groups: [
  {
    id: 'adapters',
    label: 'Adapters 01-24',
    mode: 'stacked2',
    x: 146,
    y: 10,
    portW: 16,
    portH: 16,
    gapX: 5,
    gapY: 8,
    ports: range(24, (i) => p(pad(i + 1), 'fiber'))
  }]

};

/** 24-port CAT6 patch panel, 1U. */
const patch24: DeviceTemplate = {
  id: 'patch-24',
  vendor: 'Furukawa',
  model: 'Patch Panel CAT6 24P',
  kind: 'patch',
  heightU: 1,
  passthrough: true,
  groups: [
  {
    id: 'ports',
    label: '01-24',
    mode: 'single',
    x: 146,
    y: 6,
    portW: 15,
    portH: 13,
    gapX: 3,
    ports: range(24, (i) => p(pad(i + 1)))
  }]

};

export function portName(style: PortNumberingStyle, i: number): string {
  switch (style) {
    case 'numeric':
      return String(i + 1);
    case 'padded':
      return pad(i + 1);
    case 'lan':
      return `LAN${i + 1}`;
    case 'port':
    default:
      return `P${i + 1}`;
  }
}

export function makeGenericTemplate(opts: {
  id: string;
  model?: string;
  heightU: number;
  portCount: number;
  style: PortNumberingStyle;
  media?: PortMedia;
}): DeviceTemplate {
  const inner = opts.heightU * 30 - 4;
  const portH = Math.min(14, Math.max(10, Math.round(inner / 2)));
  return {
    id: opts.id,
    vendor: 'Custom',
    model: opts.model ?? `Generic ${opts.heightU}U`,
    kind: 'generic',
    heightU: opts.heightU,
    groups: [
    {
      id: 'ports',
      label: 'Ports',
      mode: opts.portCount > 12 ? 'stacked2' : 'single',
      x: 146,
      y: opts.portCount > 12 ? 6 : Math.round((inner - portH) / 2),
      portW: opts.portCount > 24 ? 12 : 20,
      portH,
      gapX: 5,
      gapY: 5,
      ports: range(opts.portCount, (i) =>
      p(portName(opts.style, i), opts.media ?? 'copper')
      )
    }]

  };
}

const genericPrefeitura = makeGenericTemplate({
  id: 'generic-edd-prefeitura',
  model: 'Generic EDD · 1U',
  heightU: 1,
  portCount: 6,
  style: 'port'
});

export const BASE_TEMPLATES: Record<string, DeviceTemplate> = {
  [s6730.id]: s6730,
  [eddDatacom.id]: eddDatacom,
  [ne8000.id]: ne8000,
  [olt.id]: olt,
  [dio24.id]: dio24,
  [patch24.id]: patch24,
  [genericPrefeitura.id]: genericPrefeitura
};

export const KIND_LABEL: Record<DeviceTemplate['kind'], string> = {
  switch: 'Switch',
  router: 'Router',
  olt: 'OLT',
  edd: 'EDD',
  dio: 'DIO',
  patch: 'Patch panel',
  generic: 'Generic'
};