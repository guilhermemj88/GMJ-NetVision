import type {
  Connection,
  Device,
  Pop,
  Rack,
  RearLink } from
'../types/network';

export const POPS: Pop[] = [
{ id: 'pop-jardim', name: 'POP Jardim', code: 'JD', city: 'Zona Sul' },
{ id: 'pop-centro', name: 'POP Centro', code: 'CT', city: 'Centro' },
{ id: 'pop-vila-nova', name: 'POP Vila Nova', code: 'VN', city: 'Vila Nova' }];


export const RACKS: Rack[] = [
{ id: 'rack-01', popId: 'pop-jardim', name: 'Rack 01', units: 42, room: 'Sala Técnica A' },
{ id: 'rack-02', popId: 'pop-jardim', name: 'Rack 02', units: 42, room: 'Sala Técnica A' },
{ id: 'rack-03', popId: 'pop-jardim', name: 'Rack 03', units: 42, room: 'Sala Técnica B' },
{ id: 'rack-ct-01', popId: 'pop-centro', name: 'Rack 01', units: 42, room: 'Sala 2' },
{ id: 'rack-vn-01', popId: 'pop-vila-nova', name: 'Rack 01', units: 42, room: 'Contêiner' }];


export const INITIAL_DEVICES: Device[] = [
{
  id: 'pp-01',
  name: 'PP-CAT6-01',
  templateId: 'patch-24',
  rackId: 'rack-01',
  startU: 40,
  note: 'Cabeamento estruturado — prédio administrativo'
},
{
  id: 'rt-ne8000-01',
  name: 'RT-POP-NE8000-01',
  templateId: 'huawei-ne8000',
  rackId: 'rack-01',
  startU: 35,
  note: 'Borda / agregação do POP'
},
{
  id: 'sw-s6730-01',
  name: 'SW-POP-S6730-01',
  templateId: 'huawei-s6730',
  rackId: 'rack-01',
  startU: 30,
  note: 'Switch de acesso do POP'
},
{
  id: 'gen-prefeitura',
  name: 'EDD Cliente Prefeitura',
  templateId: 'generic-edd-prefeitura',
  rackId: 'rack-01',
  startU: 28,
  note: 'Equipamento genérico cadastrado pelo NOC'
},
{
  id: 'edd-datacom-01',
  name: 'EDD-DATACOM-01',
  templateId: 'datacom-edd',
  rackId: 'rack-01',
  startU: 20,
  note: 'Demarcação cliente corporativo'
},
{
  id: 'olt-ma5800-01',
  name: 'OLT-POP-MA5800-01',
  templateId: 'huawei-olt',
  rackId: 'rack-01',
  startU: 16,
  note: 'GPON — bairro Jardim'
},
{
  id: 'dio-01',
  name: 'DIO-01',
  templateId: 'dio-24f',
  rackId: 'rack-01',
  startU: 9,
  note: 'Distribuidor óptico principal'
},
{
  id: 'pp-rack02-01',
  name: 'PP-RACK02-01',
  templateId: 'patch-24',
  rackId: 'rack-02',
  startU: 41,
  note: 'Patch panel de interligação entre racks'
},
{
  id: 'sw-s6730-02',
  name: 'SW-POP-S6730-02',
  templateId: 'huawei-s6730',
  rackId: 'rack-02',
  startU: 30
}];


export const CONNECTIONS: Connection[] = [
{
  id: 'lnk-001',
  type: 'ethernet',
  status: 'connected',
  a: { deviceId: 'sw-s6730-01', portId: 'GE0/0/10' },
  b: { deviceId: 'edd-datacom-01', portId: 'LAN1' },
  circuit: 'CIR-JD-1042 · Cliente Corporativo'
},
{
  id: 'lnk-002',
  type: 'fiber',
  status: 'connected',
  a: { deviceId: 'sw-s6730-01', portId: '10GE1/0/48' },
  b: { deviceId: 'dio-01', portId: '12' },
  circuit: 'Drop óptico cliente'
},
{
  id: 'lnk-003',
  type: 'fiber',
  status: 'connected',
  a: { deviceId: 'rt-ne8000-01', portId: '100GE1/0/1' },
  b: { deviceId: 'dio-01', portId: '03' },
  circuit: 'Backbone JD ↔ CT'
},
{
  id: 'lnk-004',
  type: 'fiber',
  status: 'connected',
  a: { deviceId: 'rt-ne8000-01', portId: '10GE2/0/1' },
  b: { deviceId: 'sw-s6730-01', portId: '10GE1/0/45' },
  circuit: 'Uplink switch de acesso'
},
{
  id: 'lnk-005',
  type: 'fiber',
  status: 'degraded',
  a: { deviceId: 'olt-ma5800-01', portId: '0/1/0' },
  b: { deviceId: 'dio-01', portId: '07' },
  circuit: 'Feeder PON 07 — atenuação alta'
},
{
  id: 'lnk-006',
  type: 'ethernet',
  status: 'connected',
  a: { deviceId: 'gen-prefeitura', portId: 'P1' },
  b: { deviceId: 'sw-s6730-01', portId: 'GE0/0/22' },
  circuit: 'CIR-JD-2210 · Prefeitura'
},
{
  id: 'lnk-007',
  type: 'ethernet',
  status: 'connected',
  a: { deviceId: 'sw-s6730-01', portId: 'GE0/0/2' },
  b: { deviceId: 'pp-01', portId: '01' }
},
{
  id: 'lnk-008',
  type: 'ethernet',
  status: 'connected',
  a: { deviceId: 'sw-s6730-01', portId: 'GE0/0/24' },
  b: { deviceId: 'pp-rack02-01', portId: '05' },
  circuit: 'Interligação Rack 01 ↔ Rack 02'
},
{
  id: 'lnk-009',
  type: 'fiber',
  status: 'connected',
  a: { deviceId: 'olt-ma5800-01', portId: '0/1/1' },
  b: { deviceId: 'dio-01', portId: '08' }
},
{
  id: 'lnk-010',
  type: 'fiber',
  status: 'down',
  a: { deviceId: 'rt-ne8000-01', portId: '100GE1/0/2' },
  b: { deviceId: 'dio-01', portId: '04' },
  circuit: 'Backbone protegido — fibra rompida'
},
{
  id: 'lnk-011',
  type: 'ethernet',
  status: 'connected',
  a: { deviceId: 'edd-datacom-01', portId: 'LAN6' },
  b: { deviceId: 'pp-01', portId: '12' }
},
{
  id: 'lnk-012',
  type: 'fiber',
  status: 'connected',
  a: { deviceId: 'olt-ma5800-01', portId: '0/9/0' },
  b: { deviceId: 'sw-s6730-01', portId: '10GE1/0/46' },
  circuit: 'Uplink OLT'
},
{
  id: 'lnk-013',
  type: 'fiber',
  status: 'connected',
  a: { deviceId: 'sw-s6730-01', portId: '10GE1/0/47' },
  b: { deviceId: 'dio-01', portId: '15' },
  circuit: 'Anel metro JD ↔ VN'
},
{
  id: 'lnk-014',
  type: 'ethernet',
  status: 'connected',
  a: { deviceId: 'sw-s6730-01', portId: 'GE0/0/12' },
  b: { deviceId: 'pp-01', portId: '06' }
}];


/** Rear side of pass-through infrastructure (DIO / patch panel). */
export const REAR_LINKS: Record<string, RearLink> = {
  'dio-01:03': {
    label: 'Fibra · backbone 24F',
    type: 'fiber',
    chain: [
    { device: 'DIO-02', port: '08', note: 'POP Centro · Sala 2' },
    { device: 'SW-CENTRO-S6730-01', port: '100GE1/0/49', note: 'POP Centro' }]

  },
  'dio-01:04': {
    label: 'Fibra · rota protegida',
    type: 'fiber',
    chain: [{ device: 'DIO-02', port: '09', note: 'POP Centro · Sala 2' }]
  },
  'dio-01:07': {
    label: 'Fibra · feeder PON',
    type: 'fiber',
    chain: [{ device: 'SPLITTER-JD-07', port: '1:8', note: 'Armário 07' }]
  },
  'dio-01:08': {
    label: 'Fibra · feeder PON',
    type: 'fiber',
    chain: [{ device: 'SPLITTER-JD-11', port: '1:8', note: 'Armário 11' }]
  },
  'dio-01:12': {
    label: 'Fibra · drop cliente',
    type: 'fiber',
    chain: [{ device: 'CTO-JD-014', port: 'SP3', note: 'Rua das Acácias, 214' }]
  },
  'dio-01:15': {
    label: 'Fibra · anel metro',
    type: 'fiber',
    chain: [{ device: 'DIO-05', port: '02', note: 'POP Vila Nova' }]
  },
  'pp-01:01': {
    label: 'Cabeamento estruturado',
    type: 'ethernet',
    chain: [{ device: 'Sala Técnica · Tomada 12', port: 'RJ45', note: 'Andar 1' }]
  },
  'pp-01:06': {
    label: 'Cabeamento estruturado',
    type: 'ethernet',
    chain: [{ device: 'Recepção · Tomada 04', port: 'RJ45', note: 'Térreo' }]
  },
  'pp-01:12': {
    label: 'Cabeamento estruturado',
    type: 'ethernet',
    chain: [{ device: 'Sala Cliente · Tomada 21', port: 'RJ45', note: 'Andar 2' }]
  },
  'pp-rack02-01:05': {
    label: 'Cabeamento entre racks',
    type: 'ethernet',
    chain: [{ device: 'SW-POP-S6730-02', port: 'GE0/0/1', note: 'Rack 02' }]
  }
};